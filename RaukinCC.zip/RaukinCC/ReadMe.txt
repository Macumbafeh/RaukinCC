Raukin cc will annouce who breaks the cc on NPC's in Raids, Party, Self.
Options can be found in game by using the command /raukincc

For questions contact me
--Raukin

--v1.5 Update
- Error due to bool compare with string removed
- If destName nil will display "Unknown" instead of error

--v1.4 Update
- Made viable for all clients
- Removed Chastise for Entangle Roots and Added Scare Beast